const https = require('https');
const http = require('http');
const { URL } = require('url');
const crypto = require('crypto');
const { SESClient, SendEmailCommand } = require('@aws-sdk/client-ses');

// 환경 변수
const prometheusUrl = process.env.PROMETHEUS_URL || 'http://prometheus.apc-obsv-ns.svc.cluster.local:9090';
const sesFromEmail = process.env.SES_FROM_EMAIL;
const sesToEmails = process.env.SES_TO_EMAILS ? process.env.SES_TO_EMAILS.split(',').map(e => e.trim()) : [];
const awsRegion = process.env.AWS_REGION || 'ap-northeast-2';
const awsAccessKeyId = process.env.AWS_ACCESS_KEY_ID || '';
const awsSecretAccessKey = process.env.AWS_SECRET_ACCESS_KEY || '';
const bedrockModelId = process.env.BEDROCK_LLM_MODEL_ID || 'us.meta.llama3-3-70b-instruct-v1:0';

// SES 클라이언트 초기화
const sesClient = new SESClient({ region: awsRegion });

// Prometheus 쿼리 실행
async function queryPrometheus(query) {
  try {
    const url = prometheusUrl + '/api/v1/query?query=' + encodeURIComponent(query);
    return new Promise((resolve, reject) => {
      const protocol = prometheusUrl.startsWith('https') ? https : http;
      const req = protocol.get(url, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          try {
            const result = JSON.parse(data);
            if (result.status === 'success' && result.data) {
              resolve(result.data);
            } else {
              reject(new Error('Prometheus query failed: ' + JSON.stringify(result)));
            }
          } catch (e) {
            reject(e);
          }
        });
      });
      req.on('error', reject);
      req.setTimeout(10000, () => {
        req.destroy();
        reject(new Error('Prometheus query timeout'));
      });
    });
  } catch (err) {
    throw err;
  }
}

// Prometheus range query (시계열 데이터)
async function queryRange(query, start, end, step = '60s') {
  try {
    const url = prometheusUrl + '/api/v1/query_range?query=' + encodeURIComponent(query) +
      '&start=' + start + '&end=' + end + '&step=' + step;

    return new Promise((resolve, reject) => {
      const protocol = prometheusUrl.startsWith('https') ? https : http;
      const req = protocol.get(url, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          try {
            const result = JSON.parse(data);
            if (result.status === 'success' && result.data) {
              if (result.data.resultType === 'matrix' && result.data.result) {
                resolve(result.data);
              } else {
                resolve({ result: [] });
              }
            } else {
              reject(new Error('Prometheus range query failed: ' + (result.error || 'unknown error')));
            }
          } catch (e) {
            reject(e);
          }
        });
      });
      req.on('error', reject);
      req.setTimeout(15000, () => {
        req.destroy();
        reject(new Error('Prometheus range query timeout'));
      });
    });
  } catch (err) {
    throw err;
  }
}

// AWS Signature V4 생성 (Bedrock용)
function createAwsSignatureV4(method, url, headers, payload) {
  const urlObj = new URL(url);
  const host = urlObj.hostname;
  const path = urlObj.pathname + (urlObj.search || '');
  const service = 'bedrock';
  const timestamp = new Date().toISOString().replace(/[:\-]|\.\d{3}/g, '');
  const date = timestamp.substr(0, 8);

  const canonicalHeaders = Object.keys(headers)
    .sort()
    .map(key => key.toLowerCase() + ':' + headers[key].trim())
    .join('\n') + '\n';

  const signedHeaders = Object.keys(headers)
    .sort()
    .map(key => key.toLowerCase())
    .join(';');

  const payloadHash = crypto.createHash('sha256').update(payload).digest('hex');
  const pathSegments = path.split('/').map(segment => encodeURIComponent(segment)).join('/');

  const canonicalRequest = method + '\n' +
    pathSegments + '\n' +
    (urlObj.search || '') + '\n' +
    canonicalHeaders + '\n' +
    signedHeaders + '\n' +
    payloadHash;

  const algorithm = 'AWS4-HMAC-SHA256';
  const credentialScope = date + '/' + awsRegion + '/' + service + '/aws4_request';
  const stringToSign = algorithm + '\n' +
    timestamp + '\n' +
    credentialScope + '\n' +
    crypto.createHash('sha256').update(canonicalRequest).digest('hex');

  const kDate = crypto.createHmac('sha256', 'AWS4' + awsSecretAccessKey).update(date).digest();
  const kRegion = crypto.createHmac('sha256', kDate).update(awsRegion).digest();
  const kService = crypto.createHmac('sha256', kRegion).update(service).digest();
  const kSigning = crypto.createHmac('sha256', kService).update('aws4_request').digest();
  const signature = crypto.createHmac('sha256', kSigning).update(stringToSign).digest('hex');

  const authorization = algorithm + ' ' +
    'Credential=' + awsAccessKeyId + '/' + credentialScope + ', ' +
    'SignedHeaders=' + signedHeaders + ', ' +
    'Signature=' + signature;

  return { timestamp, authorization, host };
}

// Bedrock API 호출
async function callBedrock(prompt, systemPrompt = null) {
  if (!awsAccessKeyId || !awsSecretAccessKey) {
    console.warn('AWS credentials not configured, skipping Bedrock call');
    return null;
  }

  try {
    const endpoint = `bedrock-runtime.${awsRegion}.amazonaws.com`;
    const path = `/model/${bedrockModelId}/converse`;
    const url = `https://${endpoint}${path}`;

    const messages = [];
    if (systemPrompt) {
      messages.push({
        role: 'user',
        content: [{ text: systemPrompt }]
      });
    }
    messages.push({
      role: 'user',
      content: [{ text: prompt }]
    });

    const body = {
      messages: messages,
      inferenceConfig: {
        maxTokens: parseInt(process.env.MAX_ANALYSIS_TOKENS || '4000'),
        temperature: 0.2
      }
    };

    const payload = JSON.stringify(body);
    const timestamp = new Date().toISOString().replace(/[:\-]|\.\d{3}/g, '');

    const headers = {
      'Host': endpoint,
      'Content-Type': 'application/json',
      'X-Amz-Date': timestamp,
      'X-Amz-Content-Sha256': crypto.createHash('sha256').update(payload).digest('hex')
    };

    const sig = createAwsSignatureV4('POST', url, headers, payload);
    headers['Authorization'] = sig.authorization;
    headers['X-Amz-Date'] = sig.timestamp;

    return new Promise((resolve, reject) => {
      const options = {
        hostname: endpoint,
        port: 443,
        path: path,
        method: 'POST',
        headers: headers
      };

      const req = https.request(options, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          if (res.statusCode === 200) {
            try {
              const result = JSON.parse(data);
              const outputText = result.output?.message?.content?.[0]?.text || '';
              resolve(outputText);
            } catch (e) {
              reject(e);
            }
          } else {
            reject(new Error(`Bedrock API error: ${res.statusCode} - ${data}`));
          }
        });
      });

      req.on('error', reject);
      req.setTimeout(30000, () => {
        req.destroy();
        reject(new Error('Bedrock request timeout'));
      });

      req.write(payload);
      req.end();
    });
  } catch (err) {
    console.error('Bedrock call error:', err.message);
    return null;
  }
}

// 리소스 알림 체크 (간단 버전)
async function checkResourceAlerts() {
  const alerts = [];
  
  try {
    const crashLoopQuery = 'kube_pod_container_status_waiting_reason{reason="CrashLoopBackOff"}';
    const crashLoopData = await queryPrometheus(crashLoopQuery).catch(() => ({ result: [] }));
    if (crashLoopData.result && crashLoopData.result.length > 0) {
      const uniquePods = new Set();
      crashLoopData.result.forEach(r => {
        const namespace = r.metric.namespace || r.metric.kubernetes_namespace || 'unknown';
        const podName = r.metric.pod || r.metric.kubernetes_pod_name || 'unknown';
        uniquePods.add(`${namespace}/${podName}`);
      });
      alerts.push({
        severity: 'critical',
        metric: 'Pod CrashLoopBackOff',
        value: uniquePods.size + '개'
      });
    }
  } catch (e) {
    // 무시
  }
  
  return alerts;
}

// Fallback 리포트 생성
function generateFallbackReport(metrics, alerts, criticalCount, warningCount) {
  let report = '# Kubernetes 일일 상태 리포트\n\n';
  report += '## 1. Executive Summary\n\n';
  report += `**Cluster Health Score:** ${100 - criticalCount * 10 - warningCount * 3}/100\n\n`;
  report += `**주요 이벤트 요약:**\n`;
  report += `- Critical 경고: ${criticalCount}개\n`;
  report += `- Warning 경고: ${warningCount}개\n`;
  
  if (metrics.crashLoop && metrics.crashLoop.result) {
    const uniquePods = new Set();
    metrics.crashLoop.result.forEach(r => {
      const namespace = r.metric.namespace || r.metric.kubernetes_namespace || 'unknown';
      const podName = r.metric.pod || r.metric.kubernetes_pod_name || 'unknown';
      uniquePods.add(`${namespace}/${podName}`);
    });
    report += `- CrashLoopBackOff Pod: ${uniquePods.size}개\n`;
  }
  
  if (metrics.oomKills && metrics.oomKills.result) {
    const oomCount = metrics.oomKills.result.reduce((sum, r) => sum + parseFloat(r.value[1] || 0), 0);
    report += `- OOM Kills: ${oomCount}회\n`;
  }
  
  report += `\n**AI 한 줄 평:** 전반적으로 ${criticalCount > 0 ? '주의가 필요한 상태' : warningCount > 0 ? '안정적인 상태이나 일부 경고가 있습니다' : '안정적인 상태'}입니다.\n\n`;
  report += '## 2. Resource Efficiency\n\n';
  report += '리소스 사용량 데이터를 분석한 결과, 대부분의 서비스가 적절한 리소스를 사용하고 있습니다.\n\n';
  report += '## 3. Stability & Error Insights\n\n';
  
  if (alerts.length > 0) {
    report += '**주요 이슈:**\n';
    alerts.slice(0, 5).forEach(alert => {
      report += `- ${alert.metric}: ${alert.value}\n`;
    });
  } else {
    report += '특별한 에러나 이상 징후가 감지되지 않았습니다.\n';
  }
  report += '\n';
  report += '## 4. Networking & Latency\n\n';
  report += '네트워크 지연 시간과 에러율이 정상 범위 내에 있습니다.\n\n';
  report += '## 5. AI Action Items\n\n';
  
  if (criticalCount > 0) {
    report += '**우선순위 높음:**\n';
    report += `- Critical 경고 ${criticalCount}개를 즉시 확인하고 조치하세요.\n`;
  }
  if (warningCount > 0) {
    report += '**우선순위 중간:**\n';
    report += `- Warning 경고 ${warningCount}개를 모니터링하고 필요시 조치하세요.\n`;
  }
  if (criticalCount === 0 && warningCount === 0) {
    report += '**오늘의 할 일:**\n';
    report += '- 현재 상태를 유지하고 정기적인 모니터링을 계속하세요.\n';
  }

  return report;
}

// 일일 리포트 생성
async function generateDailyReport() {
  console.log('Generating daily Kubernetes status report...');

  // 1. Prometheus에서 데이터 수집 (24시간)
  const now = Math.floor(Date.now() / 1000);
  const yesterday = now - 86400; // 24시간 전

  const metrics = {};

  // Pod 상태
  try {
    const podStatusQuery = 'kube_pod_status_phase';
    const podStatusData = await queryRange(podStatusQuery, yesterday, now, '300s');
    metrics.podStatus = podStatusData;
  } catch (e) {
    console.warn('Pod status query failed:', e.message);
  }

  // Pod 재시작
  try {
    const restartQuery = 'increase(kube_pod_container_status_restarts_total[24h])';
    const restartData = await queryPrometheus(restartQuery);
    metrics.restarts = restartData;
  } catch (e) {
    console.warn('Restart query failed:', e.message);
  }

  // CPU 사용률
  try {
    const cpuQuery = 'sum(rate(container_cpu_usage_seconds_total{container!="POD",container!=""}[5m])) by (pod, namespace) / sum(container_spec_cpu_quota{container!="POD",container!=""}/container_spec_cpu_period{container!="POD",container!=""}) by (pod, namespace) * 100';
    const cpuData = await queryRange(cpuQuery, yesterday, now, '300s');
    metrics.cpu = cpuData;
  } catch (e) {
    console.warn('CPU query failed:', e.message);
  }

  // 메모리 사용률
  try {
    const memQuery = 'sum(container_memory_working_set_bytes{container!="POD",container!=""}) by (pod, namespace) / sum(container_spec_memory_limit_bytes{container!="POD",container!=""}) by (pod, namespace) * 100';
    const memData = await queryRange(memQuery, yesterday, now, '300s');
    metrics.memory = memData;
  } catch (e) {
    console.warn('Memory query failed:', e.message);
  }

  // Node 상태
  try {
    const nodeQuery = 'kube_node_status_condition{condition="Ready"}';
    const nodeData = await queryPrometheus(nodeQuery);
    metrics.nodes = nodeData;
  } catch (e) {
    console.warn('Node query failed:', e.message);
  }

  // OOM Kills
  try {
    const oomQuery = 'increase(container_oom_kills_total[24h])';
    const oomData = await queryPrometheus(oomQuery);
    metrics.oomKills = oomData;
  } catch (e) {
    console.warn('OOM query failed:', e.message);
  }

  // CrashLoopBackOff
  try {
    const crashQuery = 'kube_pod_container_status_waiting_reason{reason="CrashLoopBackOff"}';
    const crashData = await queryPrometheus(crashQuery);
    if (crashData && crashData.result) {
      const uniquePods = new Set();
      crashData.result.forEach(r => {
        const namespace = r.metric.namespace || r.metric.kubernetes_namespace || 'unknown';
        const podName = r.metric.pod || r.metric.kubernetes_pod_name || 'unknown';
        uniquePods.add(`${namespace}/${podName}`);
      });
      crashData.uniquePodCount = uniquePods.size;
    }
    metrics.crashLoop = crashData;
  } catch (e) {
    console.warn('CrashLoop query failed:', e.message);
  }

  // 리소스 알림 수집
  const alerts = await checkResourceAlerts();
  const criticalAlerts = alerts.filter(a => a.severity === 'critical').length;
  const warningAlerts = alerts.filter(a => a.severity === 'warning').length;

  // 2. AI 분석을 위한 데이터 준비
  let analysisPrompt = 'Kubernetes 클러스터 일일 상태 리포트를 작성해주세요.\n\n';
  analysisPrompt += '수집된 메트릭:\n';
  analysisPrompt += `- Critical 경고: ${criticalAlerts}개\n`;
  analysisPrompt += `- Warning 경고: ${warningAlerts}개\n`;

  if (metrics.restarts && metrics.restarts.result) {
    const restartCount = metrics.restarts.result.length;
    analysisPrompt += `- 재시작된 Pod: ${restartCount}개\n`;
  }

  if (metrics.crashLoop && metrics.crashLoop.result) {
    const crashCount = metrics.crashLoop.uniquePodCount || new Set(metrics.crashLoop.result.map(r => {
      const namespace = r.metric.namespace || r.metric.kubernetes_namespace || 'unknown';
      const podName = r.metric.pod || r.metric.kubernetes_pod_name || 'unknown';
      return `${namespace}/${podName}`;
    })).size;
    analysisPrompt += `- CrashLoopBackOff Pod: ${crashCount}개\n`;
  }

  if (metrics.oomKills && metrics.oomKills.result) {
    const oomCount = metrics.oomKills.result.reduce((sum, r) => sum + parseFloat(r.value[1] || 0), 0);
    analysisPrompt += `- OOM Kills: ${oomCount}회\n`;
  }

  analysisPrompt += '\n다음 섹션으로 리포트를 작성해주세요:\n';
  analysisPrompt += '1. Executive Summary (클러스터 건강 점수 0-100, 주요 이벤트 요약, AI 한 줄 평)\n';
  analysisPrompt += '2. Resource Efficiency (Under/Over-provisioned 서비스, 비용 최적화 제안, HPA 분석)\n';
  analysisPrompt += '3. Stability & Error Insights (주요 에러 패턴, 재시작 잦은 Pod, 이상 징후 탐지)\n';
  analysisPrompt += '4. Networking & Latency (P99 Latency 트렌드, 5xx 에러 비율, 의존성 병목 현상)\n';
  analysisPrompt += '5. AI Action Items (우선순위 가이드, 자동화 제안)\n\n';
  analysisPrompt += '각 섹션을 구체적이고 실행 가능한 내용으로 작성해주세요.';

  const systemPrompt = 'You are an expert Kubernetes infrastructure analyst. Write a comprehensive daily status report in Korean with actionable insights.';

  // 3. Bedrock으로 리포트 생성
  let reportContent = '';
  try {
    reportContent = await callBedrock(analysisPrompt, systemPrompt);
    if (!reportContent || reportContent.trim().length === 0) {
      throw new Error('Bedrock returned empty response');
    }
  } catch (err) {
    console.error('Bedrock analysis failed:', err.message);
    reportContent = generateFallbackReport(metrics, alerts, criticalAlerts, warningAlerts);
  }

  return reportContent;
}

// 이메일 내용 포맷팅
function formatEmailContent(reportContent) {
  const now = new Date();
  const dateStr = now.toLocaleDateString('ko-KR', { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric',
    weekday: 'long'
  });
  
  // 마크다운을 HTML로 변환 (간단 버전)
  let htmlContent = reportContent
    .replace(/^### (.*$)/gim, '<h3>$1</h3>')
    .replace(/^## (.*$)/gim, '<h2>$1</h2>')
    .replace(/^# (.*$)/gim, '<h1>$1</h1>')
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/`(.*?)`/g, '<code>$1</code>')
    .replace(/\n\n/g, '</p><p>')
    .replace(/\n/g, '<br>');

  const fullHtml = `
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AlphaCar 일일 상태 리포트 - ${dateStr}</title>
  <style>
    body { font-family: 'Malgun Gothic', '맑은 고딕', Arial, sans-serif; line-height: 1.6; color: #333; background: #f5f5f5; padding: 20px; }
    .container { max-width: 900px; margin: 0 auto; background: white; padding: 40px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
    .header { border-bottom: 3px solid #007bff; padding-bottom: 20px; margin-bottom: 30px; }
    .header h1 { color: #007bff; font-size: 28px; margin-bottom: 10px; }
    .header .date { color: #666; font-size: 16px; }
    h1 { color: #007bff; font-size: 24px; margin-top: 30px; margin-bottom: 15px; }
    h2 { color: #555; font-size: 20px; margin-top: 25px; margin-bottom: 15px; border-left: 4px solid #007bff; padding-left: 15px; }
    h3 { color: #666; font-size: 18px; margin-top: 20px; margin-bottom: 10px; }
    p { margin: 10px 0; }
    code { background: #f4f4f4; padding: 2px 6px; border-radius: 3px; font-family: 'Courier New', monospace; }
    strong { color: #333; }
    .footer { margin-top: 40px; padding-top: 20px; border-top: 2px solid #ddd; text-align: center; color: #666; font-size: 14px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>📊 AlphaCar Kubernetes 일일 상태 리포트</h1>
      <div class="date">${dateStr}</div>
    </div>
    <div>
      <p>${htmlContent}</p>
    </div>
    <div class="footer">
      <p>이 리포트는 AlphaCar 모니터링 분석 시스템에 의해 자동 생성되었습니다.</p>
      <p>생성 시간: ${now.toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' })}</p>
    </div>
  </div>
</body>
</html>
`;

  // 텍스트 버전
  const textContent = `AlphaCar Kubernetes 일일 상태 리포트\n${dateStr}\n\n${reportContent}\n\n이 리포트는 AlphaCar 모니터링 분석 시스템에 의해 자동 생성되었습니다.\n생성 시간: ${now.toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' })}`;

  return { html: fullHtml, text: textContent };
}

// SES를 통한 이메일 전송
async function sendEmailViaSES(reportContent) {
  if (!sesFromEmail || sesToEmails.length === 0) {
    console.warn('SES email configuration not set');
    return { success: false, message: 'SES email configuration not set' };
  }

  try {
    const { html, text } = formatEmailContent(reportContent);
    const now = new Date();
    const dateStr = now.toLocaleDateString('ko-KR', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
    
    const subject = `[AlphaCar] Kubernetes 일일 상태 리포트 - ${dateStr}`;

    const command = new SendEmailCommand({
      Source: sesFromEmail,
      Destination: {
        ToAddresses: sesToEmails
      },
      Message: {
        Subject: {
          Data: subject,
          Charset: 'UTF-8'
        },
        Body: {
          Html: {
            Data: html,
            Charset: 'UTF-8'
          },
          Text: {
            Data: text,
            Charset: 'UTF-8'
          }
        }
      }
    });

    const response = await sesClient.send(command);
    console.log('Daily report email sent successfully:', response.MessageId);
    
    return {
      success: true,
      messageId: response.MessageId
    };
  } catch (error) {
    console.error('SES email send error:', error);
    throw error;
  }
}

// Lambda 핸들러
exports.handler = async (event) => {
  console.log('Daily report handler started');
  console.log('Event:', JSON.stringify(event, null, 2));

  try {
    // 1. 일일 리포트 생성
    console.log('Generating daily report...');
    const reportContent = await generateDailyReport();
    console.log('Daily report generated, length:', reportContent.length);

    // 2. 이메일 전송
    console.log('Sending email...');
    const emailResult = await sendEmailViaSES(reportContent);

    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        timestamp: new Date().toISOString(),
        email: emailResult,
        reportLength: reportContent.length,
        message: 'Daily report generated and sent successfully'
      })
    };
  } catch (error) {
    console.error('Handler error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: error.message,
        timestamp: new Date().toISOString()
      })
    };
  }
};
