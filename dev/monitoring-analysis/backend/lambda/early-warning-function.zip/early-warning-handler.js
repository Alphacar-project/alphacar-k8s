const https = require('https');
const http = require('http');
const { URL } = require('url');
const crypto = require('crypto');
const { SESClient, SendEmailCommand } = require('@aws-sdk/client-ses');

// 환경 변수
const prometheusUrl = process.env.PROMETHEUS_URL || 'http://prometheus.apc-obsv-ns.svc.cluster.local:9090';
const sesFromEmail = process.env.SES_FROM_EMAIL;
const sesToEmails = process.env.SES_TO_EMAILS ? process.env.SES_TO_EMAILS.split(',').map(e => e.trim()) : [];
const awsRegion = process.env.AWS_REGION || 'ap-northeast-2';
const awsAccessKeyId = process.env.AWS_ACCESS_KEY_ID || '';
const awsSecretAccessKey = process.env.AWS_SECRET_ACCESS_KEY || '';
const bedrockModelId = process.env.BEDROCK_LLM_MODEL_ID || 'us.meta.llama3-3-70b-instruct-v1:0';

// SES 클라이언트 초기화
const sesClient = new SESClient({ region: awsRegion });

// AI 분석 결과 캐시 (같은 알림은 한 번만 분석)
const aiAnalysisCache = new Map();

// AWS Signature V4 생성 (Bedrock용)
function createAwsSignatureV4(method, url, headers, payload) {
  const urlObj = new URL(url);
  const host = urlObj.hostname;
  const path = urlObj.pathname + (urlObj.search || '');
  const service = 'bedrock';
  const timestamp = new Date().toISOString().replace(/[:\-]|\.\d{3}/g, '');
  const date = timestamp.substr(0, 8);

  const canonicalHeaders = Object.keys(headers)
    .sort()
    .map(key => key.toLowerCase() + ':' + headers[key].trim())
    .join('\n') + '\n';

  const signedHeaders = Object.keys(headers)
    .sort()
    .map(key => key.toLowerCase())
    .join(';');

  const payloadHash = crypto.createHash('sha256').update(payload).digest('hex');
  const pathSegments = path.split('/').map(segment => encodeURIComponent(segment)).join('/');

  const canonicalRequest = method + '\n' +
    pathSegments + '\n' +
    (urlObj.search || '') + '\n' +
    canonicalHeaders + '\n' +
    signedHeaders + '\n' +
    payloadHash;

  const algorithm = 'AWS4-HMAC-SHA256';
  const credentialScope = date + '/' + awsRegion + '/' + service + '/aws4_request';
  const stringToSign = algorithm + '\n' +
    timestamp + '\n' +
    credentialScope + '\n' +
    crypto.createHash('sha256').update(canonicalRequest).digest('hex');

  const kDate = crypto.createHmac('sha256', 'AWS4' + awsSecretAccessKey).update(date).digest();
  const kRegion = crypto.createHmac('sha256', kDate).update(awsRegion).digest();
  const kService = crypto.createHmac('sha256', kRegion).update(service).digest();
  const kSigning = crypto.createHmac('sha256', kService).update('aws4_request').digest();
  const signature = crypto.createHmac('sha256', kSigning).update(stringToSign).digest('hex');

  const authorization = algorithm + ' ' +
    'Credential=' + awsAccessKeyId + '/' + credentialScope + ', ' +
    'SignedHeaders=' + signedHeaders + ', ' +
    'Signature=' + signature;

  return { timestamp, authorization, host };
}

// Bedrock API 호출
async function callBedrock(prompt, systemPrompt = null) {
  if (!awsAccessKeyId || !awsSecretAccessKey) {
    console.warn('AWS credentials not configured, skipping Bedrock call');
    return null;
  }

  try {
    const endpoint = `bedrock-runtime.${awsRegion}.amazonaws.com`;
    const path = `/model/${bedrockModelId}/converse`;
    const url = `https://${endpoint}${path}`;

    const messages = [];
    if (systemPrompt) {
      messages.push({
        role: 'user',
        content: [{ text: systemPrompt }]
      });
    }
    messages.push({
      role: 'user',
      content: [{ text: prompt }]
    });

    const body = {
      messages: messages,
      inferenceConfig: {
        maxTokens: parseInt(process.env.MAX_ANALYSIS_TOKENS || '2000'),
        temperature: 0.2
      }
    };

    const payload = JSON.stringify(body);
    const timestamp = new Date().toISOString().replace(/[:\-]|\.\d{3}/g, '');

    const headers = {
      'Host': endpoint,
      'Content-Type': 'application/json',
      'X-Amz-Date': timestamp,
      'X-Amz-Content-Sha256': crypto.createHash('sha256').update(payload).digest('hex')
    };

    const sig = createAwsSignatureV4('POST', url, headers, payload);
    headers['Authorization'] = sig.authorization;
    headers['X-Amz-Date'] = sig.timestamp;

    return new Promise((resolve, reject) => {
      const options = {
        hostname: endpoint,
        port: 443,
        path: path,
        method: 'POST',
        headers: headers
      };

      const req = https.request(options, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          if (res.statusCode === 200) {
            try {
              const result = JSON.parse(data);
              const outputText = result.output?.message?.content?.[0]?.text || '';
              resolve(outputText);
            } catch (e) {
              reject(e);
            }
          } else {
            reject(new Error(`Bedrock API error: ${res.statusCode} - ${data}`));
          }
        });
      });

      req.on('error', reject);
      req.setTimeout(30000, () => {
        req.destroy();
        reject(new Error('Bedrock request timeout'));
      });

      req.write(payload);
      req.end();
    });
  } catch (err) {
    console.error('Bedrock call error:', err.message);
    return null;
  }
}

// 알림의 고유 키 생성 (중복 체크용)
function getAlertKey(alert) {
  // 메트릭 + 위치 조합으로 고유 키 생성
  return `${alert.metric}:${alert.location}`;
}

// AI 분석 및 해결책 생성 (중복 방지 - 같은 알림은 한 번만 분석)
async function enhanceAlertWithAI(alert) {
  if (!awsAccessKeyId || !awsSecretAccessKey) {
    // Bedrock이 없으면 기본 분석 사용
    return alert;
  }

  // 알림의 고유 키 생성
  const alertKey = getAlertKey(alert);
  
  // 이미 분석된 알림인지 확인 (같은 메트릭+위치 조합)
  if (aiAnalysisCache.has(alertKey)) {
    console.log(`AI analysis already exists for alert: ${alertKey}, reusing cached result`);
    const cached = aiAnalysisCache.get(alertKey);
    alert.enhancedAnalysis = cached.enhancedAnalysis;
    alert.aiEnhanced = true;
    return alert;
  }

  try {
    const prompt = `Kubernetes 클러스터에서 다음 조기경고가 발생했습니다:

**메트릭:** ${alert.metric}
**값:** ${alert.value}
**위치:** ${alert.location}
**현재 분석:** ${alert.analysis}

다음 형식으로 더 상세한 분석과 구체적인 해결책을 제공해주세요:

1. **근본 원인 분석**
   - 기술적 원인 상세 설명
   - 가능한 시나리오들

2. **즉시 조치사항**
   - kubectl 명령어를 포함한 단계별 해결 방법
   - 우선순위별 액션 아이템

3. **예방 조치**
   - 재발 방지를 위한 권장사항
   - 모니터링 개선 방안

각 섹션을 구체적이고 실행 가능한 내용으로 작성해주세요.`;

    const systemPrompt = '당신은 Kubernetes 인프라 트러블슈팅 전문가입니다. 조기경고를 분석하여 상세한 원인 분석과 실행 가능한 해결책을 한국어로 제공해야 합니다.';

    console.log(`Calling Bedrock AI for alert: ${alertKey}`);
    const aiAnalysis = await callBedrock(prompt, systemPrompt);
    
    if (aiAnalysis && aiAnalysis.trim().length > 0) {
      alert.enhancedAnalysis = aiAnalysis;
      alert.aiEnhanced = true;
      
      // 캐시에 저장 (같은 알림은 재분석하지 않음)
      aiAnalysisCache.set(alertKey, {
        enhancedAnalysis: aiAnalysis,
        timestamp: Date.now()
      });
      
      console.log(`AI analysis completed and cached for alert: ${alertKey}`);
    }
  } catch (err) {
    console.error('AI enhancement failed:', err.message);
    // 실패해도 기본 분석 사용
  }

  return alert;
}

// Prometheus 쿼리 실행
async function queryPrometheus(query) {
  try {
    const url = prometheusUrl + '/api/v1/query?query=' + encodeURIComponent(query);
    return new Promise((resolve, reject) => {
      const protocol = prometheusUrl.startsWith('https') ? https : http;
      const req = protocol.get(url, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          try {
            const result = JSON.parse(data);
            if (result.status === 'success' && result.data) {
              resolve(result.data);
            } else {
              reject(new Error('Prometheus query failed: ' + JSON.stringify(result)));
            }
          } catch (e) {
            reject(e);
          }
        });
      });
      req.on('error', reject);
      req.setTimeout(10000, () => {
        req.destroy();
        reject(new Error('Prometheus query timeout'));
      });
    });
  } catch (err) {
    throw err;
  }
}

// 리소스 모니터링 및 경고 체크
async function checkResourceAlerts() {
  const alerts = [];

  try {
    // 1. Pod CrashLoopBackOff 체크
    try {
      const crashLoopQuery = 'kube_pod_container_status_waiting_reason{reason="CrashLoopBackOff"}';
      const crashLoopData = await queryPrometheus(crashLoopQuery);
      if (crashLoopData.result && crashLoopData.result.length > 0) {
        const uniquePods = new Map();
        crashLoopData.result.forEach(r => {
          const namespace = r.metric.namespace || r.metric.kubernetes_namespace || 'unknown';
          const podName = r.metric.pod || r.metric.kubernetes_pod_name || 'unknown';
          const podKey = `${namespace}/${podName}`;
          if (!uniquePods.has(podKey)) {
            uniquePods.set(podKey, { namespace, podName, metric: r.metric });
          }
        });
        
        const failedPods = uniquePods.size;
        const podDetails = Array.from(uniquePods.keys()).join(', ');

        alerts.push({
          severity: 'critical',
          metric: 'Pod CrashLoopBackOff',
          value: failedPods + '개',
          location: podDetails,
          message: `🚨 ${failedPods}개의 Pod가 CrashLoopBackOff 상태입니다!`,
          analysis: `다음 Pod들이 계속 재시작되고 있습니다:\n📍 위치: ${podDetails}\n\n가능한 원인:\n- 애플리케이션 오류 또는 예외 발생\n- 리소스 제한 부족 (CPU/메모리)\n- 헬스체크 실패\n- 설정 오류 또는 환경 변수 문제`,
          timestamp: new Date().toISOString()
        });
      }
    } catch (e) {
      console.warn('CrashLoop check failed:', e.message);
    }

    // 2. Pod 재시작 횟수 체크 (5분 내 3회 이상)
    try {
      const restartQuery = 'increase(kube_pod_container_status_restarts_total[5m]) > 2';
      const restartData = await queryPrometheus(restartQuery);
      if (restartData.result && restartData.result.length > 0) {
        const restartingPods = restartData.result.length;
        const podDetails = restartData.result.map(r => {
          const namespace = r.metric.namespace || r.metric.kubernetes_namespace || 'unknown';
          const podName = r.metric.pod || r.metric.kubernetes_pod_name || 'unknown';
          const restartCount = Math.round(parseFloat(r.value[1]) || 0);
          return `${namespace}/${podName} (${restartCount}회)`;
        }).join(', ');

        alerts.push({
          severity: 'critical',
          metric: 'Pod 과도한 재시작',
          value: restartingPods + '개',
          location: podDetails,
          message: `🚨 ${restartingPods}개의 Pod가 5분 내 3회 이상 재시작되었습니다!`,
          analysis: `다음 Pod들이 비정상적으로 자주 재시작되고 있습니다:\n📍 위치: ${podDetails}\n\n가능한 원인:\n- 애플리케이션 오류 또는 예외 발생\n- OOM 킬 (메모리 부족)\n- 헬스체크 실패 (liveness/readiness 프로브)\n- 리소스 제한 부족`,
          timestamp: new Date().toISOString()
        });
      }
    } catch (e) {
      console.warn('Restart check failed:', e.message);
    }

    // 3. Node NotReady 상태 체크
    try {
      const nodeNotReadyQuery = 'kube_node_status_condition{condition="Ready",status="false"} == 1';
      const nodeData = await queryPrometheus(nodeNotReadyQuery);
      if (nodeData.result && nodeData.result.length > 0) {
        const notReadyNodes = nodeData.result.length;
        const nodeDetails = nodeData.result.map(r => {
          const nodeName = r.metric.node || r.metric.instance || 'unknown';
          return nodeName;
        }).join(', ');

        alerts.push({
          severity: 'critical',
          metric: 'Node NotReady',
          value: notReadyNodes + '개',
          location: nodeDetails,
          message: `🚨 ${notReadyNodes}개의 노드가 NotReady 상태입니다!`,
          analysis: `다음 노드들이 준비되지 않은 상태입니다:\n📍 위치: ${nodeDetails}\n\n가능한 원인:\n- 노드와 컨트롤 플레인 간 통신 문제\n- Kubelet 서비스 오류 또는 중단\n- 노드 리소스 부족 (CPU/메모리/디스크)\n- 네트워크 연결 문제`,
          timestamp: new Date().toISOString()
        });
      }
    } catch (e) {
      console.warn('Node check failed:', e.message);
    }

    // 4. Pod Pending 상태 체크
    try {
      const pendingQuery = 'kube_pod_status_phase{phase="Pending"} == 1';
      const pendingData = await queryPrometheus(pendingQuery);
      if (pendingData.result && pendingData.result.length > 0) {
        const pendingPods = pendingData.result.length;
        const podDetails = pendingData.result.map(r => {
          const namespace = r.metric.namespace || r.metric.kubernetes_namespace || 'unknown';
          const podName = r.metric.pod || r.metric.kubernetes_pod_name || 'unknown';
          return `${namespace}/${podName}`;
        }).join(', ');

        alerts.push({
          severity: 'warning',
          metric: 'Pod Pending',
          value: pendingPods + '개',
          location: podDetails,
          message: `⚠️ ${pendingPods}개의 Pod가 Pending 상태입니다!`,
          analysis: `다음 Pod들이 스케줄링되지 못하고 있습니다:\n📍 위치: ${podDetails}\n\n가능한 원인:\n- 클러스터 리소스 부족 (CPU/메모리)\n- 노드 셀렉터 또는 어피니티 규칙 불일치\n- PVC 바인딩 실패 또는 스토리지 문제\n- 네임스페이스 리소스 쿼터 초과`,
          timestamp: new Date().toISOString()
        });
      }
    } catch (e) {
      console.warn('Pending check failed:', e.message);
    }

    // 5. Container OOM Kills 체크
    try {
      const oomQuery = 'increase(container_oom_kills_total[5m]) > 0';
      const oomData = await queryPrometheus(oomQuery);
      if (oomData.result && oomData.result.length > 0) {
        const oomKills = oomData.result.reduce((sum, r) => sum + parseFloat(r.value[1] || 0), 0);
        const containerDetails = oomData.result.map(r => {
          const namespace = r.metric.namespace || r.metric.kubernetes_namespace || 'unknown';
          const podName = r.metric.pod || r.metric.kubernetes_pod_name || 'unknown';
          const containerName = r.metric.container || 'unknown';
          const killCount = Math.round(parseFloat(r.value[1]) || 0);
          return `${namespace}/${podName}:${containerName} (${killCount}회)`;
        }).join(', ');

        alerts.push({
          severity: 'critical',
          metric: 'Container OOM Kills',
          value: oomKills + '회',
          location: containerDetails,
          message: `🚨 최근 5분 내 ${oomKills}회의 OOM 킬이 발생했습니다!`,
          analysis: `다음 컨테이너들이 메모리 부족으로 강제 종료되었습니다:\n📍 위치: ${containerDetails}\n\n가능한 원인:\n- 메모리 리소스 제한이 부족함\n- 애플리케이션 메모리 누수\n- 메모리 사용량 급증 (트래픽 증가 등)\n- 컨테이너 메모리 제한 설정 오류`,
          timestamp: new Date().toISOString()
        });
      }
    } catch (e) {
      console.warn('OOM check failed:', e.message);
    }

    // 6. Pod CPU 사용률 체크 (85% 이상)
    try {
      const podCpuQuery = 'sum(rate(container_cpu_usage_seconds_total{container!="POD",container!=""}[5m])) by (pod, namespace) / sum(container_spec_cpu_quota{container!="POD",container!=""}/container_spec_cpu_period{container!="POD",container!=""}) by (pod, namespace) * 100 > 85';
      const podCpuData = await queryPrometheus(podCpuQuery);
      if (podCpuData.result && podCpuData.result.length > 0) {
        const highCpuPods = podCpuData.result.length;
        const podDetails = podCpuData.result.map(r => {
          const namespace = r.metric.namespace || 'unknown';
          const podName = r.metric.pod || 'unknown';
          const cpuUsage = parseFloat(r.value[1]) || 0;
          return `${namespace}/${podName} (${cpuUsage.toFixed(1)}%)`;
        }).join(', ');

        alerts.push({
          severity: 'warning',
          metric: 'Pod CPU 사용률 높음',
          value: highCpuPods + '개',
          location: podDetails,
          message: `⚠️ ${highCpuPods}개의 Pod가 CPU 사용률 85% 이상입니다!`,
          analysis: `다음 Pod들의 CPU 사용률이 높습니다:\n📍 위치: ${podDetails}\n\n가능한 원인:\n- CPU 리소스 제한이 부족함\n- 애플리케이션 처리량 증가\n- 비효율적인 코드 또는 알고리즘\n- 외부 요청 증가로 인한 부하`,
          timestamp: new Date().toISOString()
        });
      }
    } catch (e) {
      console.warn('CPU check failed:', e.message);
    }

    // 7. Pod 메모리 사용률 체크 (90% 이상)
    try {
      const podMemUsageQuery = '(sum(container_memory_working_set_bytes{container!="POD",container!=""}) by (pod, namespace) / sum(container_spec_memory_limit_bytes{container!="POD",container!=""} > 0) by (pod, namespace)) * 100';
      const podMemUsageData = await queryPrometheus(podMemUsageQuery);
      
      const highMemPods = [];
      if (podMemUsageData.result && podMemUsageData.result.length > 0) {
        podMemUsageData.result.forEach(r => {
          const memUsage = parseFloat(r.value[1]) || 0;
          if (!isNaN(memUsage) && isFinite(memUsage) && memUsage > 90) {
            highMemPods.push(r);
          }
        });
      }
      
      if (highMemPods.length > 0) {
        const podDetails = highMemPods.map(r => {
          const namespace = r.metric.namespace || 'unknown';
          const podName = r.metric.pod || 'unknown';
          const memUsage = parseFloat(r.value[1]) || 0;
          return `${namespace}/${podName} (${memUsage.toFixed(1)}%)`;
        }).join(', ');

        alerts.push({
          severity: 'critical',
          metric: 'Pod 메모리 사용률 위험',
          value: highMemPods.length + '개',
          location: podDetails,
          message: `🚨 ${highMemPods.length}개의 Pod가 메모리 사용률 90% 이상입니다!`,
          analysis: `다음 Pod들의 메모리 사용률이 매우 높습니다:\n📍 위치: ${podDetails}\n\n⚠️ OOM 킬이 발생할 위험이 있습니다!\n\n가능한 원인:\n- 메모리 리소스 제한이 부족함\n- 애플리케이션 메모리 누수\n- 메모리 사용량 급증\n- 컨테이너 메모리 제한 설정 오류`,
          timestamp: new Date().toISOString()
        });
      }
    } catch (e) {
      console.warn('Memory check failed:', e.message);
    }

    // 8. 노드 디스크 사용률 체크 (85% 이상)
    try {
      const diskQuery = '100 - (node_filesystem_avail_bytes{mountpoint="/"} / node_filesystem_size_bytes{mountpoint="/"} * 100)';
      const diskData = await queryPrometheus(diskQuery);
      if (diskData.result && diskData.result.length > 0) {
        diskData.result.forEach(result => {
          const diskUsage = parseFloat(result.value[1]);
          const node = result.metric.instance || 'unknown';
          if (diskUsage > 90) {
            alerts.push({
              severity: 'critical',
              metric: '노드 디스크 사용률',
              value: diskUsage.toFixed(2) + '%',
              location: `노드: ${node}`,
              message: `🚨 노드 ${node}의 디스크 사용률이 ${diskUsage.toFixed(2)}%로 위험 수준입니다!`,
              analysis: `노드의 디스크 공간이 거의 가득 찼습니다:\n📍 위치: 노드 ${node}\n\n⚠️ 위험:\n- Pod가 스케줄링되지 못할 수 있음\n- 이미지 pull이 실패할 수 있음\n- 노드가 NotReady 상태로 전환될 수 있음\n\n가능한 원인:\n- 미사용 Docker 이미지 및 컨테이너\n- 로그 파일 누적\n- PVC 데이터 증가\n- 임시 파일 누적`,
              timestamp: new Date().toISOString()
            });
          } else if (diskUsage > 85) {
            alerts.push({
              severity: 'warning',
              metric: '노드 디스크 사용률',
              value: diskUsage.toFixed(2) + '%',
              location: `노드: ${node}`,
              message: `⚠️ 노드 ${node}의 디스크 사용률이 ${diskUsage.toFixed(2)}%로 높습니다!`,
              analysis: `노드의 디스크 사용률이 높아지고 있습니다:\n📍 위치: 노드 ${node}\n\n⚠️ 조치를 취하지 않으면 곧 위험 수준(90%)에 도달할 수 있습니다.\n\n권장 조치:\n- 미사용 이미지 및 컨테이너 정리\n- 로그 파일 정리\n- 디스크 사용량 모니터링 강화`,
              timestamp: new Date().toISOString()
            });
          }
        });
      }
    } catch (e) {
      console.warn('Disk check failed:', e.message);
    }

  } catch (err) {
    console.error('Resource check error:', err.message);
  }

  return alerts;
}

// 조기경고 체크 (추가 이상 징후 감지)
async function checkEarlyWarnings() {
  const earlyWarnings = [];

  try {
    // 1. CPU 사용률 급증 감지 (5분 내 20% 이상 증가)
    try {
      const cpuSpikeQuery = 'rate(container_cpu_usage_seconds_total{container!="POD",container!=""}[5m]) * 100';
      const cpuCurrent = await queryPrometheus(cpuSpikeQuery).catch(() => null);
      const cpuPreviousQuery = 'rate(container_cpu_usage_seconds_total{container!="POD",container!=""}[10m]) offset 5m * 100';
      const cpuPrevious = await queryPrometheus(cpuPreviousQuery).catch(() => null);
      
      if (cpuCurrent && cpuPrevious && cpuCurrent.result && cpuPrevious.result) {
        const currentAvg = cpuCurrent.result.reduce((sum, r) => sum + parseFloat(r.value[1] || 0), 0) / cpuCurrent.result.length;
        const previousAvg = cpuPrevious.result.reduce((sum, r) => sum + parseFloat(r.value[1] || 0), 0) / cpuPrevious.result.length;
        
        if (currentAvg > previousAvg * 1.2 && currentAvg > 50) {
          earlyWarnings.push({
            severity: 'warning',
            metric: 'CPU 사용률 급증',
            value: `${currentAvg.toFixed(1)}%`,
            location: '클러스터 전체',
            message: `⚠️ CPU 사용률이 5분 내 ${((currentAvg / previousAvg - 1) * 100).toFixed(1)}% 급증했습니다!`,
            analysis: `CPU 사용률이 ${previousAvg.toFixed(1)}%에서 ${currentAvg.toFixed(1)}%로 급증했습니다.\n\n가능한 원인:\n- 트래픽 급증\n- 배치 작업 실행\n- 리소스 경합`,
            timestamp: new Date().toISOString(),
            trend: 'spike'
          });
        }
      }
    } catch (e) {
      console.warn('CPU spike check failed:', e.message);
    }

    // 2. 메모리 사용률 급증 감지
    try {
      const memCurrentQuery = 'avg(container_memory_working_set_bytes{container!="POD",container!=""}) / 1024 / 1024 / 1024';
      const memCurrent = await queryPrometheus(memCurrentQuery).catch(() => null);
      const memPreviousQuery = 'avg(container_memory_working_set_bytes{container!="POD",container!=""} offset 5m) / 1024 / 1024 / 1024';
      const memPrevious = await queryPrometheus(memPreviousQuery).catch(() => null);
      
      if (memCurrent && memPrevious && memCurrent.result && memPrevious.result && memCurrent.result.length > 0 && memPrevious.result.length > 0) {
        const currentMem = parseFloat(memCurrent.result[0].value[1] || 0);
        const previousMem = parseFloat(memPrevious.result[0].value[1] || 0);
        
        if (currentMem > previousMem * 1.15 && currentMem > 1) {
          earlyWarnings.push({
            severity: 'warning',
            metric: '메모리 사용률 급증',
            value: `${currentMem.toFixed(2)}GB`,
            location: '클러스터 전체',
            message: `⚠️ 메모리 사용률이 5분 내 ${((currentMem / previousMem - 1) * 100).toFixed(1)}% 급증했습니다!`,
            analysis: `메모리 사용률이 ${previousMem.toFixed(2)}GB에서 ${currentMem.toFixed(2)}GB로 급증했습니다.\n\n가능한 원인:\n- 메모리 누수 가능성\n- 대용량 데이터 처리\n- 캐시 증가`,
            timestamp: new Date().toISOString(),
            trend: 'spike'
          });
        }
      }
    } catch (e) {
      console.warn('Memory spike check failed:', e.message);
    }

    // 3. Pod 재시작 빈도 감지
    try {
      const restartQuery = 'rate(kube_pod_container_status_restarts_total[5m])';
      const restartData = await queryPrometheus(restartQuery).catch(() => null);
      
      if (restartData && restartData.result && restartData.result.length > 0) {
        const highRestartPods = restartData.result.filter(r => parseFloat(r.value[1] || 0) > 0.1);
        
        if (highRestartPods.length > 0) {
          const podDetails = highRestartPods.map(r => {
            const namespace = r.metric.namespace || 'unknown';
            const podName = r.metric.pod || 'unknown';
            const restartRate = parseFloat(r.value[1] || 0);
            return `${namespace}/${podName} (${(restartRate * 60).toFixed(1)}회/시간)`;
          }).join(', ');
          
          earlyWarnings.push({
            severity: 'warning',
            metric: 'Pod 재시작 빈도 높음',
            value: `${highRestartPods.length}개`,
            location: podDetails,
            message: `⚠️ ${highRestartPods.length}개의 Pod가 빈번하게 재시작되고 있습니다!`,
            analysis: `다음 Pod들이 빈번하게 재시작되고 있습니다:\n📍 위치: ${podDetails}\n\n가능한 원인:\n- 헬스체크 실패\n- 리소스 부족으로 인한 OOM\n- 애플리케이션 오류`,
            timestamp: new Date().toISOString(),
            trend: 'frequent_restarts'
          });
        }
      }
    } catch (e) {
      console.warn('Restart frequency check failed:', e.message);
    }
  } catch (err) {
    console.error('Early warning check error:', err.message);
  }

  return earlyWarnings;
}

// 이메일 내용 포맷팅
function formatEmailContent(alerts) {
  const criticalAlerts = alerts.filter(a => a.severity === 'critical');
  const warningAlerts = alerts.filter(a => a.severity === 'warning');
  
  const now = new Date();
  const dateStr = now.toLocaleString('ko-KR', { timeZone: 'Asia/Seoul' });
  
  let htmlContent = `
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AlphaCar 조기경고 알림</title>
  <style>
    body { font-family: 'Malgun Gothic', '맑은 고딕', Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 800px; margin: 0 auto; padding: 20px; }
    .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; }
    .summary { background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 20px; }
    .alert { margin: 15px 0; padding: 15px; border-radius: 8px; border-left: 4px solid; }
    .alert-critical { background: #fff5f5; border-left-color: #dc3545; }
    .alert-warning { background: #fffbf0; border-left-color: #ffc107; }
    .alert-title { font-size: 18px; font-weight: bold; margin-bottom: 10px; }
    .alert-metric { color: #666; font-size: 14px; margin-bottom: 5px; }
    .alert-location { color: #666; font-size: 14px; margin-bottom: 10px; }
    .alert-analysis { background: white; padding: 10px; border-radius: 4px; margin-top: 10px; white-space: pre-wrap; }
    .footer { margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; text-align: center; color: #666; font-size: 12px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>🚨 AlphaCar 조기경고 알림</h1>
      <p>생성 시간: ${dateStr}</p>
    </div>
    
    <div class="summary">
      <h2>📊 요약</h2>
      <p><strong>Critical 알림:</strong> ${criticalAlerts.length}개</p>
      <p><strong>Warning 알림:</strong> ${warningAlerts.length}개</p>
      <p><strong>전체 알림:</strong> ${alerts.length}개</p>
    </div>
`;

  // Critical 알림
  if (criticalAlerts.length > 0) {
    htmlContent += '<h2 style="color: #dc3545;">🔴 Critical 알림</h2>';
    criticalAlerts.forEach(alert => {
      htmlContent += `
    <div class="alert alert-critical">
      <div class="alert-title">${alert.message}</div>
      <div class="alert-metric"><strong>메트릭:</strong> ${alert.metric}</div>
      <div class="alert-metric"><strong>값:</strong> ${alert.value}</div>
      <div class="alert-location"><strong>📍 위치:</strong> ${alert.location}</div>
      <div class="alert-analysis"><strong>기본 분석:</strong>\n${alert.analysis}</div>
      ${alert.enhancedAnalysis ? `<div class="alert-analysis" style="background: #e8f4f8; padding: 15px; margin-top: 10px; border-radius: 4px; border-left: 3px solid #007bff;"><strong>🤖 AI 상세 분석 및 해결책:</strong><br>${alert.enhancedAnalysis.replace(/\n/g, '<br>')}</div>` : ''}
    </div>
`;
    });
  }

  // Warning 알림
  if (warningAlerts.length > 0) {
    htmlContent += '<h2 style="color: #ffc107; margin-top: 30px;">⚠️ Warning 알림</h2>';
    warningAlerts.forEach(alert => {
      htmlContent += `
    <div class="alert alert-warning">
      <div class="alert-title">${alert.message}</div>
      <div class="alert-metric"><strong>메트릭:</strong> ${alert.metric}</div>
      <div class="alert-metric"><strong>값:</strong> ${alert.value}</div>
      <div class="alert-location"><strong>📍 위치:</strong> ${alert.location}</div>
      <div class="alert-analysis"><strong>기본 분석:</strong>\n${alert.analysis}</div>
      ${alert.enhancedAnalysis ? `<div class="alert-analysis" style="background: #e8f4f8; padding: 15px; margin-top: 10px; border-radius: 4px; border-left: 3px solid #007bff;"><strong>🤖 AI 상세 분석 및 해결책:</strong><br>${alert.enhancedAnalysis.replace(/\n/g, '<br>')}</div>` : ''}
    </div>
`;
    });
  }

  htmlContent += `
    <div class="footer">
      <p>이 알림은 AlphaCar 모니터링 시스템에 의해 자동 생성되었습니다.</p>
      <p>대시보드에서 더 자세한 정보를 확인하실 수 있습니다.</p>
    </div>
  </div>
</body>
</html>
`;

  // 텍스트 버전
  let textContent = `AlphaCar 조기경고 알림\n`;
  textContent += `생성 시간: ${dateStr}\n\n`;
  textContent += `요약:\n`;
  textContent += `- Critical 알림: ${criticalAlerts.length}개\n`;
  textContent += `- Warning 알림: ${warningAlerts.length}개\n`;
  textContent += `- 전체 알림: ${alerts.length}개\n\n`;

  alerts.forEach(alert => {
    textContent += `${alert.severity.toUpperCase()}: ${alert.message}\n`;
    textContent += `메트릭: ${alert.metric}\n`;
    textContent += `값: ${alert.value}\n`;
    textContent += `위치: ${alert.location}\n`;
    textContent += `기본 분석:\n${alert.analysis}\n\n`;
    if (alert.enhancedAnalysis) {
      textContent += `🤖 AI 상세 분석 및 해결책:\n${alert.enhancedAnalysis}\n\n`;
    }
  });

  return { html: htmlContent, text: textContent };
}

// SES를 통한 이메일 전송
async function sendEmailViaSES(alerts) {
  if (!sesFromEmail || sesToEmails.length === 0) {
    console.warn('SES email configuration not set');
    return { success: false, message: 'SES email configuration not set' };
  }

  if (alerts.length === 0) {
    console.log('No alerts to send');
    return { success: true, message: 'No alerts to send' };
  }

  try {
    const { html, text } = formatEmailContent(alerts);
    const criticalCount = alerts.filter(a => a.severity === 'critical').length;
    const warningCount = alerts.filter(a => a.severity === 'warning').length;
    
    const subject = `[AlphaCar] 조기경고 알림 - Critical: ${criticalCount}개, Warning: ${warningCount}개`;

    const command = new SendEmailCommand({
      Source: sesFromEmail,
      Destination: {
        ToAddresses: sesToEmails
      },
      Message: {
        Subject: {
          Data: subject,
          Charset: 'UTF-8'
        },
        Body: {
          Html: {
            Data: html,
            Charset: 'UTF-8'
          },
          Text: {
            Data: text,
            Charset: 'UTF-8'
          }
        }
      }
    });

    const response = await sesClient.send(command);
    console.log('Email sent successfully:', response.MessageId);
    
    return {
      success: true,
      messageId: response.MessageId,
      alertsCount: alerts.length,
      criticalCount,
      warningCount
    };
  } catch (error) {
    console.error('SES email send error:', error);
    throw error;
  }
}

// Lambda 핸들러
exports.handler = async (event) => {
  console.log('Early warning handler started');
  console.log('Event:', JSON.stringify(event, null, 2));

  try {
    // 1. 리소스 알림 체크
    console.log('Checking resource alerts...');
    const resourceAlerts = await checkResourceAlerts();
    console.log(`Found ${resourceAlerts.length} resource alerts`);

    // 2. 조기경고 체크
    console.log('Checking early warnings...');
    const earlyWarnings = await checkEarlyWarnings();
    console.log(`Found ${earlyWarnings.length} early warnings`);

    // 3. 모든 알림 통합 및 우선순위별 정렬
    const allAlerts = [...resourceAlerts, ...earlyWarnings];
    const severityOrder = { 'critical': 0, 'warning': 1, 'info': 2 };
    allAlerts.sort((a, b) => {
      const severityDiff = (severityOrder[a.severity] || 99) - (severityOrder[b.severity] || 99);
      if (severityDiff !== 0) return severityDiff;
      return (new Date(b.timestamp || 0) - new Date(a.timestamp || 0));
    });

    // 4. 최근 1시간 내 알림만 필터링
    const oneHourAgo = Date.now() - 3600000;
    const recentAlerts = allAlerts.filter(alert => {
      const alertTime = alert.timestamp ? new Date(alert.timestamp).getTime() : Date.now();
      return alertTime > oneHourAgo;
    });

    console.log(`Total recent alerts: ${recentAlerts.length}`);

    // 5. AI 분석 및 해결책 추가 (Critical 알림 우선, 중복 방지)
    if (recentAlerts.length > 0) {
      console.log('Enhancing alerts with AI analysis (duplicate prevention enabled)...');
      const criticalAlerts = recentAlerts.filter(a => a.severity === 'critical');
      const otherAlerts = recentAlerts.filter(a => a.severity !== 'critical');
      
      // Critical 알림부터 AI 분석 (최대 3개, 중복 제외)
      const processedKeys = new Set();
      let criticalCount = 0;
      for (let i = 0; i < criticalAlerts.length && criticalCount < 3; i++) {
        const alertKey = getAlertKey(criticalAlerts[i]);
        if (!processedKeys.has(alertKey)) {
          await enhanceAlertWithAI(criticalAlerts[i]);
          processedKeys.add(alertKey);
          criticalCount++;
        } else {
          console.log(`Skipping duplicate alert: ${alertKey}`);
        }
      }
      
      // Warning 알림도 최대 2개까지 AI 분석 (중복 제외)
      let warningCount = 0;
      for (let i = 0; i < otherAlerts.length && warningCount < 2; i++) {
        const alertKey = getAlertKey(otherAlerts[i]);
        if (!processedKeys.has(alertKey)) {
          await enhanceAlertWithAI(otherAlerts[i]);
          processedKeys.add(alertKey);
          warningCount++;
        } else {
          console.log(`Skipping duplicate alert: ${alertKey}`);
        }
      }
      
      console.log(`AI analysis completed: ${criticalCount} critical, ${warningCount} warning (duplicates skipped)`);
    }

    // 6. 알림이 있으면 이메일 전송
    let emailResult = null;
    if (recentAlerts.length > 0) {
      console.log('Sending email notification...');
      emailResult = await sendEmailViaSES(recentAlerts);
    } else {
      console.log('No recent alerts, skipping email');
    }

    return {
      statusCode: 200,
      body: JSON.stringify({
        success: true,
        timestamp: new Date().toISOString(),
        alerts: {
          total: recentAlerts.length,
          critical: recentAlerts.filter(a => a.severity === 'critical').length,
          warning: recentAlerts.filter(a => a.severity === 'warning').length,
          info: recentAlerts.filter(a => a.severity === 'info').length
        },
        email: emailResult,
        message: recentAlerts.length > 0 
          ? `Found ${recentAlerts.length} alerts and sent email notification`
          : 'No alerts found'
      })
    };
  } catch (error) {
    console.error('Handler error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        success: false,
        error: error.message,
        timestamp: new Date().toISOString()
      })
    };
  }
};
